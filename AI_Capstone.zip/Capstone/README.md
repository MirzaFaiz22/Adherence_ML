# Kepatuhan Model API

Panduan singkat untuk menjalankan server FastAPI dan contoh pemanggilan endpoint `/predict`.

Prasyarat
- Python virtualenv aktif dan dependensi terinstall (`requirements.txt`).

Menjalankan server
1. Aktifkan virtualenv (PowerShell):
```powershell
& d:\Dicoding\Capstone\venv\Scripts\Activate.ps1
```
2. Install dependensi (jika perlu):
```powershell
pip install -r requirements.txt
```
3. Jalankan server:
```powershell
python -m uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Endpoint berguna
- `GET /health` — cek apakah model dan scaler berhasil dimuat.
- `GET /docs` — Swagger UI interaktif.
- `POST /reload` — muat ulang model & scaler tanpa restart.
- `POST /predict` — lakukan inferensi.

Menentukan panjang fitur yang benar
Jika Anda tidak tahu berapa banyak fitur yang diharapkan, jalankan di terminal Python:
```powershell
python -c "import joblib; s=joblib.load('scaler.pkl'); print('all_features_len =', s.mean_.shape[0])"
python -c "import joblib; s=joblib.load('scaler_select.pkl'); print('selected_features_len =', s.mean_.shape[0])"
```

Contoh `curl` (PowerShell)
Ganti array dengan panjang yang sesuai hasil perintah di atas.
```powershell
curl -X POST http://127.0.0.1:8000/predict `
 -H "Content-Type: application/json" `
 -d '{"all_features": [0.0, 0.1, 0.2, /* ... ganti dengan nilai hingga panjang yang benar */], "selected_features": [0.5, 0.6, /* ... */] }'
```

Contoh klien Python
```python
import requests
url = 'http://127.0.0.1:8000/predict'
payload = {
  "all_features": [
    2.0,
    1.0,
    2.0,
    2.0,
    1.0,
    4.0,
    3.0,
    3.0,
    5.0,
    2.0,
    3.0,
    3.0,
    5.0,
    5.0,
    1.0,
    1.0,
    1.0,
    0.0,
    1.0,
    1.0,
    4.0,
    5.0,
    5.0,
    1.0,
    4.0,
    5.0,
    4.0,
    1.0,
    4.0,
    5.0,
    0.0,
    2.0,
    4.0,
    6.0,
    3.0,
    14.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    0.0,
    1.0,
    0.0
  ],
  "selected_features": [
    0.0,
    1.0,
    0.0,
    1.0,
    1.0,
    1.0,
    4.0,
    3.0
  ]
}

resp = requests.post(url, json=payload)
print(resp.status_code)
print(resp.json())
```

Debugging cepat
- Jika menerima 503 model not loaded: jalankan `curl -X POST http://127.0.0.1:8000/reload` lalu periksa log uvicorn.
- Jika menerima 400 length error: sesuaikan panjang array input sesuai `scaler.mean_.shape[0]`.

Butuh bantuan membuat payload valid atau contoh lengkap berdasarkan scaler Anda? Kirim output dari:
```powershell
python -c "import joblib; print('all_len=', joblib.load('scaler.pkl').mean_.shape[0]); print('sel_len=', joblib.load('scaler_select.pkl').mean_.shape[0])"
```

---
File utama: `app.py` (FastAPI) — buka [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
